Erick Hideki Taira 222011525
Matheus Chagas Lopes 222011599

Para realizar o emparelhamento dos times seguindo as restrições estabelecidas, foi inicialmente criado um grafo em que os vértices representavam os times e as arestas indicavam as restrições entre eles. 

**Início do Algoritmo:**

1. **Coloração dos Vértices**: Aplicou-se o algoritmo de coloração de vértices para garantir que times com restrições de enfrentamento direto tivessem cores diferentes.

2. **Rebalanceamento dos Vértices**: Após a coloração, os vértices foram rebalanceados para dividir os times em duas categorias: mandantes (representados pela cor vermelha) e visitantes (representados pelas outras cores).

3. **Emparelhamento Inicial**: Foi realizado um emparelhamento inicial entre mandantes e visitantes, assegurando que as restrições de enfrentamento fossem respeitadas.

4. **Emparelhamento Interno dos Mandantes**: Como os mandantes foram inicialmente agrupados sem conflitos diretos, foi possível realizar o emparelhamento entre esses times sem violar as restrições.

5. **Reaplicação do Algoritmo de Coloração para Visitantes**: Para os visitantes, a situação era mais complexa devido às possíveis restrições internas. Portanto, foi reaplicado o algoritmo para esses vértices.

Infelizmente, o algoritmo não foi capaz de gerar o resultado esperado, porém foi encontrado um resultado relativamente próximo.